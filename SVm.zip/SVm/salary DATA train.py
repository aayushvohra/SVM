# -*- coding: utf-8 -*-
"""
Created on Thu Oct 29 20:46:03 2020

@author: AAYUSH VOHRA
"""
import pandas as pd 
import numpy as np 
import seaborn as sns
letters = pd.read_csv("G:/practical data science/Assignments/SVm/SalaryData_Train.csv")
letters.head()
letters.describe()
letters.columns
sns.boxplot(x="age",y="capitalgain",data=letters,palette = "hls")
sns.boxplot(x="capitalgain",y="age",data=letters,palette = "hls")
#sns.pairplot(data=letters)

from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
train,test = train_test_split(letters,test_size = 0.3)
test.head()
train_X = train.iloc[:,1:]
train_X 
train_y = train.iloc[:,0]
train_y
test_X  = test.iloc[:,1:]
test_X
test_y  = test.iloc[:,0]
test_y 
#kernel = linear
#help(SVC)
model_linear = SVC(kernel = "linear")
model_linear.fit(train_y,train_X)
pred_test_linear = model_linear.predict(test_X)
pred_test_linear
np.mean(pred_test_linear==test_y)
# Kernel = poly
model_poly = SVC(kernel = "poly")
model_poly.fit(train_X,train_y)
pred_test_poly = model_poly.predict(test_X)

np.mean(pred_test_poly==test_y)

# kernel = rbf # radial base funciton
model_rbf = SVC(kernel = "rbf")
model_rbf.fit(train_X,train_y)
pred_test_rbf = model_rbf.predict(test_X)

np.mean(pred_test_rbf==test_y)